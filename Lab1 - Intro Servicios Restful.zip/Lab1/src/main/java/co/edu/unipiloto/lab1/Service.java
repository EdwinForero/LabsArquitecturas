/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package co.edu.unipiloto.lab1;

import co.edu.unipiloto.ws.lab1.entidad.Person;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;
import static javax.swing.text.html.FormSubmitEvent.MethodType.POST;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

/**
 *
 * @author edwin
 */
@Path("service")
public class Service {

    Person person = new Person();
    private final double minSalary = 899995;
    private static Map<Integer, Person> persons = new HashMap<Integer, Person>();

    static {
        for (int i = 0; i < 10; i++) {
            Person person = new Person();
            int id = i + 1;
            person.setId(id);
            person.setFullName("My wonderfull person " + id);
            person.setAge(new Random().nextInt(40) + i);
            person.setSalary(new Random().nextInt(100) + i);
            persons.put(id, person);
        }
    }

    @GET
    @Path("/getAllPersonsInXML")
    @Produces(MediaType.APPLICATION_XML)    
    public List<Person> getAllPersonsInXML(){
       return new ArrayList<>(persons.values());
    }

    @GET
    @Path("/getAllPersonsInJSON")
    @Produces(MediaType.APPLICATION_JSON)
    public List<Person> getAllPersonsInJSON(){
       return new ArrayList<>(persons.values());
    }

    @GET
    @Path("/getAllPersonsByIdJSON/{id}")
    @Produces(MediaType.APPLICATION_JSON)
    public Person getAllPersonsByIdJSON(@PathParam("id")int id){
        return persons.get(id);
    }

    @GET
    @Path("/getAllPersonsByIdXML/{id}")
    @Produces(MediaType.APPLICATION_JSON)
    public Person getAllPersonsByIdXML(@PathParam("id")int id){
        return persons.get(id);
    }
    
    @POST
    @Path("/addPersonInJSON")
    @Produces(MediaType.APPLICATION_JSON)
    @Consumes(MediaType.APPLICATION_JSON)
    public Person addPersonInJSON(Person person){
       person.setSalary(minSalary*person.getAge()/3); //Calculamos y asignamos el salario
       return persons.put(person.getId(), person);
    }

    @GET
    @Path("/avgSalary")
    @Produces(MediaType.TEXT_PLAIN)
    private String avgSalary(){
        String avgSalaryx = Double.toString((double)sumSalary()/ persons.size());
        return "El promedio de salarios es: $" + avgSalaryx;
    }

    @GET
    @Path("/sumSalary")
    @Produces(MediaType.APPLICATION_JSON)
    public String sumSalaryToStr(){
        return "La suma total de salarios es: $" + sumSalary();
    }
    
    private double sumSalary(){
        double sum = 0;
        for(Person p: persons.values()){
            sum += p.getSalary();
        }
        return sum;
    }
}
